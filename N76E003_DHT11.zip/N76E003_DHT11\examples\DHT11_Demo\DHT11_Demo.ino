#include <Arduino.h>
#include <DHT11.h>

/*
  DHT11 Temperature & Humidity Sensor for Nuvoton N76E003
  Sensor Pin: P1.7 (Arduino Pin 3) or any digital pin
*/

DHT11 dht;
const int dhtPin = 3; // Pin 3 is P1.7

void setup(void) {
    Serial.begin(115200);
    delay(200);

    Serial.println("==========================================");
    Serial.println("    Nuvoton N76E003 DHT11 Weather Station ");
    Serial.println("==========================================");

    DHT11_init(&dht, dhtPin);
}

void loop(void) {
    int result = DHT11_read(&dht);

    if (result == DHT11_OK) {
        Serial.print("Humidity: ");
        Serial.print_num(dht.humidity);
        Serial.print(" %  |  Temperature: ");
        Serial.print_num(dht.temperature);
        Serial.println(" C");
    } else if (result == DHT11_ERROR_TIMEOUT) {
        Serial.println("[ERROR] Sensor timeout - check 5V, GND, and DATA pin connection!");
    } else if (result == DHT11_ERROR_CHECKSUM) {
        Serial.println("[ERROR] Checksum error - noisy signal or loose jumper wire!");
    }

    // DHT11 requires at least 1.5 - 2.0 seconds between samples
    delay(2000);
}

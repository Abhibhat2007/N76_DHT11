/**
 * @file N76_DHT11.c
 * @brief DHT11 single-wire communication driver calibrated for 16MHz 1T 8051
 */

#include "N76_DHT11.h"

void N76_DHT11_init(N76_DHT11 *dht, uint8_t pin) {
    dht->pin = pin;
    dht->temperature = 0;
    dht->humidity = 0;
    dht->status = DHT11_OK;
    digitalWrite(pin, HIGH);
    pinMode(pin, INPUT_PULLUP);
}

int N76_DHT11_read(N76_DHT11 *dht) {
    uint8_t data[5];
    uint8_t i, j;
    uint16_t timeout;
    uint8_t pin = dht->pin;

    data[0] = data[1] = data[2] = data[3] = data[4] = 0;

    /* 1. Host Start Signal: Pull LOW for 20ms */
    pinMode(pin, OUTPUT);
    digitalWrite(pin, LOW);
    delay(20);

    /* 2. Release line: immediately switch to INPUT_PULLUP */
    digitalWrite(pin, HIGH);
    pinMode(pin, INPUT_PULLUP);
    delayMicroseconds(30);

    noInterrupts();

    /* 3. Wait for DHT11 response (pulls line LOW) */
    timeout = 2000;
    while (digitalRead(pin) == HIGH) {
        if (--timeout == 0) {
            interrupts();
            dht->status = DHT11_ERR_NO_RESPONSE;
            return DHT11_ERR_NO_RESPONSE;
        }
    }

    /* 4. Wait for DHT11 80us LOW response to end (goes HIGH) */
    timeout = 2000;
    while (digitalRead(pin) == LOW) {
        if (--timeout == 0) {
            interrupts();
            dht->status = DHT11_ERR_TIMEOUT_LOW;
            return DHT11_ERR_TIMEOUT_LOW;
        }
    }

    /* 5. Wait for DHT11 80us HIGH response to end (goes LOW) */
    timeout = 2000;
    while (digitalRead(pin) == HIGH) {
        if (--timeout == 0) {
            interrupts();
            dht->status = DHT11_ERR_TIMEOUT_HI;
            return DHT11_ERR_TIMEOUT_HI;
        }
    }

    /* 6. Read 40 data bits */
    for (i = 0; i < 5; i++) {
        for (j = 0; j < 8; j++) {
            uint16_t lowCount = 0;
            uint16_t highCount = 0;

            /* Measure 50us LOW pulse */
            while (digitalRead(pin) == LOW) {
                if (++lowCount >= 2000) {
                    interrupts();
                    dht->status = DHT11_ERR_TIMEOUT_BIT;
                    return DHT11_ERR_TIMEOUT_BIT;
                }
            }

            /* Measure HIGH pulse (26-28us for '0', 70us for '1') */
            while (digitalRead(pin) == HIGH) {
                if (++highCount >= 2000) {
                    interrupts();
                    dht->status = DHT11_ERR_TIMEOUT_BIT;
                    return DHT11_ERR_TIMEOUT_BIT;
                }
            }

            data[i] <<= 1;
            /* 70us HIGH > 50us LOW => bit 1; 26us HIGH < 50us LOW => bit 0 */
            if (highCount > lowCount) {
                data[i] |= 1;
            }
        }
    }

    interrupts();

    /* 7. Verify Checksum */
    if ((uint8_t)(data[0] + data[1] + data[2] + data[3]) != data[4]) {
        dht->status = DHT11_ERR_CHECKSUM;
        return DHT11_ERR_CHECKSUM;
    }

    dht->humidity = data[0];
    dht->temperature = data[2];
    dht->status = DHT11_OK;

    return DHT11_OK;
}

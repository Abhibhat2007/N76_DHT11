#ifndef __DHT11_H__
#define __DHT11_H__
#include "N76_DHT11.h"
#endif

/**
 * @file N76_DHT11.h
 * @brief Conflict-free DHT11 sensor library for Nuvoton N76E003 (8051)
 */

#ifndef __N76_DHT11_H__
#define __N76_DHT11_H__

#include <Arduino.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Status codes */
#define DHT11_OK                0
#define DHT11_ERR_NO_RESPONSE  -1  /* Sensor did not pull line low */
#define DHT11_ERR_TIMEOUT_LOW  -2  /* Sensor 80us low response timed out */
#define DHT11_ERR_TIMEOUT_HI   -3  /* Sensor 80us high response timed out */
#define DHT11_ERR_TIMEOUT_BIT  -4  /* Data bit read timed out */
#define DHT11_ERR_CHECKSUM     -5  /* Data checksum mismatch */

typedef struct {
    uint8_t pin;
    uint8_t temperature;
    uint8_t humidity;
    int status;
} N76_DHT11;

/* Compatibility alias */
typedef N76_DHT11 DHT11;

void N76_DHT11_init(N76_DHT11 *dht, uint8_t pin);
int N76_DHT11_read(N76_DHT11 *dht);

#define DHT11_init N76_DHT11_init
#define DHT11_read N76_DHT11_read

#ifdef __cplusplus
}
#endif

#endif /* __N76_DHT11_H__ */
